# Self-Documenting Code Guidelines

## Philosophy
Write code that tells a story so clear that explanatory comments become redundant. The code itself should be the primary documentation, with every element contributing to immediate comprehension.

## Core Principles

### 1. Intention-Revealing Names
Choose names that explain why something exists, what it does, and how it's used.

**Functions and Methods:**
- Use verb phrases that describe the exact action
- Include the expected outcome in the name
- Avoid abbreviations and cryptic shortcuts

```javascript
// Instead of: calc()
calculateMonthlyInterestRate()

// Instead of: validate()
ensureEmailFormatIsValid()

// Instead of: process()
convertRawDataToUserProfile()
```

**Variables:**
- Use nouns that clearly indicate the data's purpose
- Include units and context when relevant
- Prefer longer, descriptive names over brevity

```javascript
// Instead of: time
sessionTimeoutInMinutes

// Instead of: users
activeUsersEligibleForPromotion

// Instead of: flag
hasCompletedOnboardingProcess
```

**Constants:**
- Use descriptive names that explain business rules
- Include context about when/why the value is used

```javascript
// Instead of: MAX_SIZE
MAXIMUM_FILE_UPLOAD_SIZE_IN_BYTES

// Instead of: TIMEOUT
DATABASE_CONNECTION_TIMEOUT_SECONDS
```

### 2. Function Design Principles

**Single Responsibility:**
Each function should do one thing completely and well.

```javascript
// Instead of a monolithic function
function processUserRegistration(userData) {
    validateUserInput(userData);
    hashPassword(userData.password);
    saveUserToDatabase(userData);
    sendWelcomeEmail(userData.email);
    logRegistrationEvent(userData.id);
}
```

**Pure Functions When Possible:**
Functions should return the same output for the same input without side effects.

```javascript
function calculateTotalPriceWithTax(basePrice, taxRate) {
    return basePrice * (1 + taxRate);
}
```

**Descriptive Return Values:**
Return values should be self-explanatory.

```javascript
function findUserByEmail(email) {
    // Returns null if not found, user object if found
    return database.users.find(user => user.email === email) || null;
}
```

### 3. Code Structure and Flow

**Guard Clauses:**
Handle edge cases early to reduce nesting and improve readability.

```javascript
function calculateDiscount(user, orderAmount) {
    if (!user.isPremiumMember) return 0;
    if (orderAmount < MINIMUM_ORDER_FOR_DISCOUNT) return 0;
    if (user.hasUsedDiscountThisMonth) return 0;
    
    return orderAmount * PREMIUM_DISCOUNT_RATE;
}
```

**Meaningful Abstractions:**
Extract complex logic into well-named functions.

```javascript
function shouldApproveTransaction(transaction, user) {
    return hasValidPaymentMethod(user) &&
           isWithinDailyLimit(transaction, user) &&
           passesSecurityChecks(transaction);
}
```

### 4. Data Structure Clarity

**Descriptive Object Properties:**
Use property names that clearly indicate their purpose and expected values.

```javascript
const userSubscription = {
    isActiveSubscription: true,
    billingCycleInDays: 30,
    nextBillingDateUTC: '2025-08-18T00:00:00Z',
    subscriptionTierName: 'premium',
    autoRenewalEnabled: true
};
```

**Explicit State Management:**
Make state transitions and conditions obvious.

```javascript
const orderStatus = {
    isPending: true,
    isProcessing: false,
    isShipped: false,
    isDelivered: false,
    isCancelled: false
};

function markOrderAsProcessing(order) {
    return {
        ...order,
        status: {
            isPending: false,
            isProcessing: true,
            isShipped: false,
            isDelivered: false,
            isCancelled: false
        }
    };
}
```

### 5. Error Handling Patterns

**Descriptive Error Types:**
Create specific error classes that explain what went wrong.

```javascript
class EmailAlreadyExistsError extends Error {
    constructor(email) {
        super(`User with email ${email} already exists in the system`);
        this.name = 'EmailAlreadyExistsError';
    }
}

class InsufficientFundsError extends Error {
    constructor(requiredAmount, availableAmount) {
        super(`Transaction requires ${requiredAmount} but only ${availableAmount} available`);
        this.name = 'InsufficientFundsError';
    }
}
```

**Explicit Validation:**
Make validation rules obvious and easy to understand.

```javascript
function validatePasswordStrength(password) {
    const hasMinimumLength = password.length >= 8;
    const containsUppercase = /[A-Z]/.test(password);
    const containsLowercase = /[a-z]/.test(password);
    const containsNumber = /\d/.test(password);
    const containsSpecialCharacter = /[!@#$%^&*]/.test(password);
    
    if (!hasMinimumLength) {
        throw new InvalidPasswordError('Password must be at least 8 characters long');
    }
    
    if (!containsUppercase || !containsLowercase) {
        throw new InvalidPasswordError('Password must contain both uppercase and lowercase letters');
    }
    
    if (!containsNumber) {
        throw new InvalidPasswordError('Password must contain at least one number');
    }
    
    if (!containsSpecialCharacter) {
        throw new InvalidPasswordError('Password must contain at least one special character');
    }
}
```

### 6. Control Flow Clarity

**Explicit Conditional Logic:**
Make boolean expressions read like natural language.

```javascript
function canUserAccessPremiumFeatures(user) {
    const hasActiveSubscription = user.subscription.isActive;
    const subscriptionNotExpired = user.subscription.expirationDate > new Date();
    const paymentMethodValid = user.paymentMethod.isValid;
    
    return hasActiveSubscription && subscriptionNotExpired && paymentMethodValid;
}

if (canUserAccessPremiumFeatures(currentUser)) {
    displayPremiumDashboard();
} else {
    displayUpgradePrompt();
}
```

**Readable Loop Operations:**
Use descriptive iteration variables and clear loop purposes.

```javascript
function calculateTotalRevenueFromActiveSubscriptions(subscriptions) {
    let totalRevenue = 0;
    
    for (const subscription of subscriptions) {
        if (subscription.isActive && !subscription.isTrialPeriod) {
            totalRevenue += subscription.monthlyPrice;
        }
    }
    
    return totalRevenue;
}
```

### 7. Type Safety and Contracts

**Clear Function Signatures:**
Use TypeScript or JSDoc to make expected inputs and outputs explicit.

```javascript
/**
 * Converts user input to a standardized user profile
 * @param {Object} rawUserData - Unvalidated user registration data
 * @param {string} rawUserData.email - User's email address
 * @param {string} rawUserData.password - Plain text password
 * @param {string} rawUserData.firstName - User's first name
 * @param {string} rawUserData.lastName - User's last name
 * @returns {Promise<UserProfile>} Validated and formatted user profile
 */
async function createUserProfileFromRegistrationData(rawUserData) {
    // Implementation
}
```

### 8. Business Logic Transparency

**Domain-Specific Language:**
Use terminology that matches the business domain.

```javascript
function calculateLoyaltyPointsEarned(purchase) {
    const basePoints = purchase.totalAmount;
    const bonusPoints = purchase.isFirstPurchase ? FIRST_PURCHASE_BONUS : 0;
    const tierMultiplier = getTierMultiplierForUser(purchase.userId);
    
    return (basePoints + bonusPoints) * tierMultiplier;
}

function isEligibleForFreeShipping(order, user) {
    const meetsMinimumOrderValue = order.subtotal >= FREE_SHIPPING_THRESHOLD;
    const isPremiumMember = user.membershipTier === 'premium';
    const isPromotionalPeriod = isCurrentlyInFreeShippingPromotion();
    
    return meetsMinimumOrderValue || isPremiumMember || isPromotionalPeriod;
}
```

## Anti-Patterns to Avoid

### 1. Hungarian Notation and Cryptic Prefixes
```javascript
// Avoid: strUserName, intUserAge, bIsActive
// Use: userName, userAge, isActive
```

### 2. Mental Mapping Requirements
```javascript
// Avoid: processing data where variables need translation
for (let i = 0; i < users.length; i++) {
    const u = users[i];
    if (u.s === 'active') { // What is 's'? What is 'active'?
        // process
    }
}

// Use: clear, descriptive variables
for (const user of users) {
    if (user.accountStatus === 'active') {
        processActiveUser(user);
    }
}
```

### 3. Magic Numbers and Strings
```javascript
// Avoid: mysterious values embedded in code
if (user.loginAttempts > 3) {
    lockAccount(user);
}

// Use: named constants with context
const MAXIMUM_LOGIN_ATTEMPTS_BEFORE_LOCKOUT = 3;

if (user.loginAttempts > MAXIMUM_LOGIN_ATTEMPTS_BEFORE_LOCKOUT) {
    lockUserAccountForSecurity(user);
}
```

### 4. Unclear Boolean Logic
```javascript
// Avoid: complex conditions without explanation
if (!user.isActive && (user.lastLogin < cutoffDate || user.purchases === 0)) {
    // What business rule does this represent?
}

// Use: extracted, named conditions
function shouldDeactivateInactiveUser(user) {
    const accountIsCurrentlyActive = user.isActive;
    const hasNotLoggedInRecently = user.lastLogin < INACTIVITY_CUTOFF_DATE;
    const hasNeverMadePurchase = user.purchases === 0;
    
    return !accountIsCurrentlyActive && (hasNotLoggedInRecently || hasNeverMadePurchase);
}
```

## Implementation Strategy

1. **Start with naming**: Spend extra time choosing names that eliminate confusion
2. **Extract explanatory functions**: If you need a comment to explain code, extract it into a well-named function instead
3. **Use the business language**: Align code terminology with domain experts and stakeholders
4. **Optimize for reading**: Code is read 10x more than it's written
5. **Test your clarity**: If someone unfamiliar with the code can't understand it quickly, improve the naming and structure

## Quality Check Questions

Before considering code complete, ask:
- Can someone unfamiliar with this codebase understand what each function does from its name alone?
- Are the business rules and logic immediately apparent from reading the code?
- Would I need to explain this code to a colleague, or is it self-evident?
- Do variable and function names eliminate the need for mental translation?
- Does the code structure tell the story of what the system does?

## Benefits

When code is truly self-documenting:
- Onboarding new team members becomes faster
- Code reviews focus on logic rather than understanding
- Maintenance and debugging become more efficient
- Business stakeholders can better understand system behavior
- Technical debt accumulates more slowly
- Refactoring becomes less risky and more straightforward

Remember: The goal is not to eliminate all comments, but to make explanatory comments unnecessary. API documentation, business context, and architectural decisions may still benefit from documentation, but the day-to-day logic should speak for itself.